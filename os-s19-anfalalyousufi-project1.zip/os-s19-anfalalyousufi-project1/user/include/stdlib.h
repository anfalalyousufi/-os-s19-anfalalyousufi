#ifndef _USER_STDLIB_H_
#define _USER_STDLIB_H_

int atoi(const char *, int *);

#endif /* !_USER_STDLIB_H_ */
