#include <lib/trap.h>
#include <lib/x86.h>

tf_t uctx_pool[NUM_IDS];
