#ifndef _KERN_TRAP_TTRAPHANDLER_H_
#define _KERN_TRAP_TTRAPHANDLER_H_

#include <lib/trap.h>

void trap (tf_t *);

#endif

