#ifndef _KERN_TRAP_TSYSCALL_H_
#define _KERN_TRAP_TSYSCALL_H_

void sys_puts(void);
void sys_spawn(void);
void sys_yield(void);

#endif

