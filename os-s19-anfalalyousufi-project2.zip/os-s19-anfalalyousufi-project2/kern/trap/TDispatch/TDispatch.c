/***********************
 * anfal alyousufi     *
 * 30th oct 2019       *
 * *********************/

#include <lib/syscall.h>

#include "import.h"

/** TASK 1:
  * * Dispatch the system call to appropriate functions based on syscall number.
  *   	- The function contracts are defined in import.h
  *   In case an invalid syscall number is provided, set the errno to: E_INVAL_CALLNR
  *   (error numbers defined in lib/syscall.h)
  *   
  */
void syscall_dispatch(void)
{
	// TODO
	unsigned int nr;
	nr = syscall_get_arg1();

	switch(nr){
		//sys_puts
		case SYS_puts: //string to the screen :op
			sys_puts();
			break;

		case SYS_spawn://new process: create
			sys_spawn();
			break;
			                
		case SYS_yield:    //called by a process to abandon its cpu slice                    
			sys_yield();			                        
			break;
	
		defualt:
			syscall_set_errno(E_INVAL_CALLNR);
			break;
	}
}
