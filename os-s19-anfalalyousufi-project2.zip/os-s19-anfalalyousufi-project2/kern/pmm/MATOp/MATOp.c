#include <lib/debug.h>
#include "import.h"

/******************
 * anfal alyousufi
 * feb 16th 
 * *****************/

//reviewed: 23th feb

#define PAGESIZE	4096
#define VM_USERLO	0x40000000
#define VM_USERHI	0xf0000000
#define VM_USERLO_PI	(VM_USERLO / PAGESIZE)
#define VM_USERHI_PI	(VM_USERHI / PAGESIZE)

/** TASK 1:
  * Allocation of a physical page.
  *
  * 1. - First, implement a naive page allocator that scans the allocation table (AT) 
  *      using the functions defined in import.h to find the first unallocated page
  *      with usable permission.
  *    
  *    Hint 1: (Q: Do you have to scan allocation table from index 0? Recall how you have
  *    			initialized the table in pmem_init.)
  *    
  *    - Then mark the page as allocated in the allocation table and return the page
  *    	 index of the page found. In the case when there is no available page found,
  *      return 0.
  * 2. Optimize the code with the memorization techniques so that you do not have to
  *    scan the allocation table from scratch every time.
  */

//global variable for last page searched so that it doesn't scratch everytime
//static unsigned int last = VM_USERLO_PI;

unsigned int
palloc()
{
	//TODO
	
	int i;

	for(i=VM_USERLO_PI; i< VM_USERHI_PI; i++){

		if(at_is_norm(i) == 1 && at_is_allocated(i) == 0){

			at_set_allocated(i, 1);

			return i;
		}
	}
	return 0;
}


/*unsigned int
palloc()
{
  // TODO
  //
  unsigned int i;
  for (i=last; i < VM_USERHI_PI; i++){
	  if(at_is_allocated(i) == 0 && at_is_norm(i)==1){
		  at_set_allocated(i,1);
		  //last = i;
		  return i;
		  if (last == VM_USERHI_PI -1)
			  last = VM_USERLO_PI;
		  break;
	  }
  }

  return 0;
} 

unsigned int naive_palloc(){
	unsigned int i;
	for (i = VM_USERLO_PI; i < VM_USERHI_PI; i++){

		if(at_is_allocated(i) == 0 && at_is_norm(i)){
			at_set_allocated(i,1);
			return i;
		}
	}
	return 0;
}

unsigned int
palloc()
{
	//TODO
	static unsigned int start = VM_USERLO_PI;
	for(; start< VM_USERHI_PI; start++){
		
		if(at_is_allocated(start) == 0 && at_is_norm(start)){
			at_set_allocated(start,1);
			return start;
		}
	}
}

*/
/**************************************************************************************************/

/** TASK 2:
  * Free of a physical page.
  *
  * This function marks the page with given index as unallocated in the allocation table.
  *
  * Hint: Simple. You have already implemented the functions required to check if a page
  * 	  is allocated and to set the allocation status of a page index. (See import.h)
  */
void
pfree(unsigned int pfree_index)
{
  // TODO
 // if (pfree_index < get_nps()){
	  at_set_allocated(pfree_index, 0);
  //}
}
