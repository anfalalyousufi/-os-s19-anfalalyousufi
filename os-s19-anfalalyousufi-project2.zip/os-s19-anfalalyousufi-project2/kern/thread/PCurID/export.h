#ifndef _KERN_THREAD_PCURID_H_
#define _KERN_THREAD_PCURID_H_

unsigned int get_curid(void);
void set_curid(unsigned int curid);

#endif

