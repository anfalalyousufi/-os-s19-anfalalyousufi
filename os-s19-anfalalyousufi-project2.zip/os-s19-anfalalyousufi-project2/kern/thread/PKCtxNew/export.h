#ifndef _KERN_THREAD_PKCTXNEW_H_
#define _KERN_THREAD_PKCTXNEW_H_

unsigned int kctx_new(void *entry, unsigned int id, unsigned int quota);

#endif

