/*********************
 *  anfal alyousufi  *
 *  March 29th 2019  *
 * reviewed: 3rd     *
 *********************/

#include <lib/gcc.h>
#include <lib/x86.h>

#include "import.h"

extern char STACK_LOC[NUM_IDS][PAGESIZE] gcc_aligned(PAGESIZE);

/** TASK 1:
  * * Allocate memory for the new child thread, then set the eip, and esp
  *   of the thread states. The eip should be set to [entry], and the
  *   esp should be set to the corresponding stack TOP in STACK_LOC.
  *   Don't forget the stack is going down from high address to low.
  *   We do not care about the rest of states when a new thread starts.
  *   The function returns the child thread (process) id.
  *
  *  Hint 1: 
  *  - The alloc_mem_quota function will return the pid of the child process. 
  *    Use this to set the eip and esp in the context using functions defined in import.h.
  *  Hint 2: 
  *  - Set eip to [entry]
  *  - Set esp to corresponding stack TOP in STACK_LOC. 
  *    i.e. Address of STACK_LOC[child][PAGESIZE - 1]. Remember that the stack is going down from high address to low.
  *  Hint 3:
  *  - Return the child pid.
  */



/*****************************************************************************************************
// need to use 3 functions defined in import.h								
// unsigned int alloc_mem_quota (.. id, quota)
// void kctx_set_esp (pid,*esp)
// void kctx_set_eip (pid, *eip)
//
// use STACK_LOC data structure in PKCtxNew.c (2D array stores the kernel stack for each process)
// extern char STACK_LOC[NUM_IDS][PAAGESIZE] gcc_aligned(PAGESIZE);
******************************************************************************************************/
unsigned int kctx_new(void *entry, unsigned int id, unsigned int quota)
{

  // TODO
  int child_pid = alloc_mem_quota(id,quota); //return pid of the child process

   kctx_set_eip(child_pid, entry);
   kctx_set_esp(child_pid, (void*)&STACK_LOC[child_pid][PAGESIZE-1]); //id /id+1

    //dprintf("PKCtxNew---%s \n",STACK_LOC[child_pid][PAGESIZE-1]);
    //dprintf("PKCtxNew---%s \n",&STACK_LOC[child_pid][PAGESIZE-1]);

  	return child_pid;
  //return 0;

    if (entry <0 || id > NUM_IDS){
        return 0;  //fail on set up a new child thread
      }
 
}

