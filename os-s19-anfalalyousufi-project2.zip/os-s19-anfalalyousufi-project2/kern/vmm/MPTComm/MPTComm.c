#include <lib/x86.h>

#include "import.h"

#define PAGESIZE  4096
#define VM_USERLO 0x40000000
#define VM_USERHI 0xF0000000
#define VM_USERLO_PI  (VM_USERLO / PAGESIZE)   // VM_USERLO page index
#define VM_USERHI_PI  (VM_USERHI / PAGESIZE)   // VM_USERHI page index


#define DIR_MASK    0xffc00000
#define PAGE_MASK   0x003ff000
#define OFFSET_MASK 0x00000fff
#define NUM_IDS 64


/*******************
 * anfal alyousufi *
 * feb 22nd        *
 * *****************/
/** TASK 1:
  * * For each process from id 0 to NUM_IDS -1,
  *   set the page directory entries so that the kernel portion of the map as identity map,
  *   and the rest of page directories are unmmaped.
  * 
  * Hint 1: Recall which portions are reserved for the kernel and calculate the pde_index.       
  * Hint 2: Recall which function in MPTIntro layer is used to set identity map. (See import.h) 
  * Hint 3: Remove the page directory entry to unmap it.
  */
void pdir_init(unsigned int mbi_adr)
{
    // TODO: define your local variables here.
    //unsigned int proc_index, pde_index;
    unsigned int i,j;
    idptbl_init(mbi_adr);
/*
    unsigned int PG_LO = (0x40000000 >> 22);
    unsigned int PG_HI = (0xF0000000 >> 22);

*/

    for(i = 0; i < NUM_IDS-1; i++){
	    for(j = 0; j< 1024; j++){

		    int proc_index  = i;
		    int pde=j;

		    if(pde*1024 < VM_USERLO_PI || pde*1024 >= VM_USERHI_PI){

			   set_pdir_entry_identity(proc_index, pde);

		    }else{
			    rmv_pdir_entry(proc_index, pde);
		    }
	    }
    }
}
/*
    
   

    // TODO
    for (proc_index = 0; proc_index <NUM_IDS; proc_index++){
	    for(pde_index=0; pde_index < NUM_IDS; proc_index++){
		    if (pde_index < PG_LO || pde_index >= PG_HI){
			    set_pdir_entry_identity(proc_index, pde_index);
		    }else{
			    rmv_pdir_entry(proc_index, pde_index);
		    }
	    }
    }
    
}
*/
/******************************************************************************************/
/** TASK 2:
  * * 1. Allocate a page (with container_alloc) for the page table,
  * * 2. Check if the page was allocated and register the allocated page in page directory for the given virtual address.
  * * 3. Clear (set to 0) all the page table entries for this newly mapped page table.
  * * 4. Return the page index of the newly allocated physical page.
  * 	 In the case when there's no physical page available, it returns 0.
  */
unsigned int alloc_ptbl(unsigned int proc_index, unsigned int vadr)
{

	//TODO
	int pd_index = (DIR_MASK & vadr)>>22;
	int pt_index = (PAGE_MASK & vadr)>>12;
	int offset = (OFFSET_MASK & vadr);
/*
	int page_index = container_alloc(proc_index);
	set_pdir_entry_by_va(proc_index, vadr, page_index);

	if(page_index!=0)
	{
		for(int i = 0; i < 1024; i++)
		{
			rmv_ptbl_entry(proc_index, pd_index, i);
			return page_index;
		}
		return 0;
	}
}

*/	
  // TODO
  unsigned int page_id, pde_index, pte_index;
  if (proc_index <= NUM_IDS && proc_index > 0)
  {
	  page_id = container_alloc(proc_index);
	  if (page_id == 0)
	  {
		  return 0;
	  }
	  set_pdir_entry_by_va(proc_index, vadr, page_id);
	   pd_index = vadr>> 22;
	  
	  for (pt_index = 0; pt_index < 1024; pt_index++)
	  
	  {
		  rmv_ptbl_entry(proc_index, pd_index, pt_index);
	  }
	  
	  return page_id;
	  
  }
  
return 0;

}


/****************************************************************************************************/

/** TASK 3:
  * * Reverse operation of alloc_ptbl.
  *   - Remove corresponding page directory entry
  *   - Free the page for the page table entries (with container_free).
  * Hint 1: Find the pde corresponding to vadr (MPTOp layer)
  * Hint 2: Remove the pde (MPTOp layer)
  * Hint 3: Use container free
  */
void free_ptbl(unsigned int proc_index, unsigned int vadr)
{
	//TODO
	unsigned int pd_index = (DIR_MASK & vadr) >> 22;
	unsigned int pt_index = (PAGE_MASK & vadr) >> 12;

	unsigned int pte_index;

	for (pte_index = 0; pte_index < 1024; pte_index++)
	{
		rmv_pdir_entry_by_va(proc_index, vadr);
	}
	container_free(proc_index,pd_index);
}


/*
  // TODO
  unsigned int pde_address = vadr >> 22;
  unsigned int pte_index= vadr>>12;
  pde_address = get_pdir_entry_by_va(proc_index, vadr);
  for(pte_index = 0; pte_index < 1024; pte_index++)
  {
	  container_free(proc_index, ((unsigned int *)pde_address)[pte_index]);
	  }
  rmv_pdir_entry_by_va(proc_index, vadr);
*/
  
