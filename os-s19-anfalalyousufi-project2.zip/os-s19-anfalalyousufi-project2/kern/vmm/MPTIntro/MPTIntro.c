#include <lib/gcc.h>
#include <lib/x86.h>
#include <lib/debug.h>

#include "import.h"

#define PT_PERM_UP 0
#define PT_PERM_PTU (PTE_P | PTE_W | PTE_U)

/*******************
 * anfal alyousufi
 * 17th feb 
 * *****************/


//review: 23th feb


/** ASSIGNMENT INFO:
  * - In this part of the kernel, we will be implementing Virtual Memory Management (VMM) with 
  *   two level paging mechanism.
  * - Like with PMM section, we need certain data structures and abstractions over these structures 
  *   to access and modify them. (See project handout for description of abstraction layers.)
  * - Each abstraction layer is a sub-folder within the vmm folder and is organised the same as 
  *   pmm layer with files export.h, import.h, test.c, <layer_name>.c and the Makefile.inc.
  *
  * HELPFUL LINKS ON PAGING:
  * - Intel 80386 Programmer’s Reference Manual: http://flint.cs.yale.edu/cs422/readings/i386/s05_02.htm
  */ 

/** * VMM Data Structure: PDirPool
  * - We will maintain one page structure for each process.
  * - We will statically allocate page directories, and maintain the second level page tables dynamically.
  * - We have a Page directory pool for NUM_IDS processes.
  *   -- Each PDirPool[index] represents the page directory of the page structure for the process # [index].
  * - We will have a maximum of NUM_IDS (=64) processes. 
  * - The PAGESIZE for VMM is 4096 bytes. 
  * - Each Page Table Entry (pte) is 4 bytes. Therefore, each page can hold 4096/4 = 1024 pte.
  * Page Table Entry Format:
  * 
  * |31                         12|11          |2   |1   |0  | 
  * |-----------------------------|------------|----|----|---|
  * | Page Frame Address 31..12   |  Flags     |U/S |R/W |P  |
  *
  * - U/S = User / Supervisor bit
  * - R/W = Read / Write bit
  * - P   = Present bit
  */
char * PDirPool[NUM_IDS][1024] gcc_aligned(PAGESIZE);

/** * VMM Data Structure: IDPTbl
  * - In mCertiKOS, we use identity page table mappings for the kernel memory.
  * - IDPTbl is a statically allocated, identity page table that will be reused for
  *   all the kernel memory.
  * - Every page directory entry of kernel memory links to corresponding entry in IDPTbl.
  */
unsigned int IDPTbl[1024][1024] gcc_aligned(PAGESIZE);


/******************************************************************************************************/
/** TASK 1:
  * * Set the CR3 register with the start address of the page structure for process # [index]
  */


void set_pdir_base(unsigned int index)
{
    // TODO

     if (index >= NUM_IDS){
	    return; //id exceeds boundry

	   }
    //from import.h use set_cr3() function
    set_cr3(PDirPool[index]);
    
}

/******************************************************************************************************/
/** TASK 2:
  * * Return the page directory entry # [pde_index] of the process # [proc_index]
  * - This can be used to test whether the page directory entry is mapped
  *   *
  */


unsigned int get_pdir_entry(unsigned int proc_index, unsigned int pde_index)
{

    // TODO
    return(unsigned int) PDirPool[proc_index][pde_index];
    //return 0;

}   

/*****************************************************************************************************/

/** TASK 3:
  * * Set specified page directory entry with the start address of physical page # [page_index].
  * - You should also set the permissions PTE_P, PTE_W, and PTE_U
  * Hint 1: PT_PERM_PTU is defined for you.
  * Hint 2: 
  */


void set_pdir_entry(unsigned int proc_index, unsigned int pde_index, unsigned int page_index)
{
	//TODO
	    if (proc_index >= NUM_IDS || pde_index >= 1024)
		 {
		    return;
		}


	int * initial_Add = page_index << 12;
	PDirPool[proc_index][pde_index] = (int) initial_Add |  PT_PERM_PTU;
}



       
//	PDirPool[proc_index][pde_index] = (char*)(page_index * PAGESIZE + PT_PERM_PTU);
	


/***************************************************************************************************/
/** TASK 4:
  * * Set the page directory entry # [pde_index] for the process # [proc_index]
  *   with the initial address of page directory # [pde_index] in IDPTbl
  * - You should also set the permissions PTE_P, PTE_W, and PTE_U
  * - This will be used to map the page directory entry to identity page table.
  * Hint 1: Cast the first entry of IDPTbl[pde_index] to char *.
  */

void set_pdir_entry_identity(unsigned int proc_index, unsigned int pde_index)
{
     

    // TODO
    if (proc_index >= NUM_IDS || pde_index >= 1024)
    
    {
	    return;
    }

    PDirPool[proc_index][pde_index] = (char*)((unsigned int)IDPTbl[pde_index]|PT_PERM_PTU);

   
 } 


/***************************************************************************************************/
/** TASK 5:
  * * Remove specified page directory entry 
  * Hint 1: Set the page directory entry to PT_PERM_UP.
  * Hint 2: Don't forget to cast the value to (char *).
  */

void rmv_pdir_entry(unsigned int proc_index, unsigned int pde_index)
{
	
    // TODO
    PDirPool[proc_index][pde_index]=(char *)PT_PERM_UP;  

}   

/**************************************************************************************************/
/** TASK 6:
  * * Returns the specified page table entry.
  * Hint 1: Remember that second level page table is dynamically allocated. You cannot simply 
  *         use array indexing as in the first level page table. The offset into the second level
  *         page table can be calculated using: pte_index * size of pte.
  * Hint 2: Do not forget that the permission info is also stored in the page directory entries.
  *         (You will have to mask out the permission info.)
  * Hint 3: Remember to cast to a pointer before de-referencing an address.
  */

unsigned int get_ptbl_entry(unsigned int proc_index, unsigned int pde_index, unsigned int pte_index)
{   
	
    // TODO
   unsigned int page_table = 0;

  if(proc_index >= 0 && proc_index < NUM_IDS) {
	 if(pde_index >= 0 && pde_index < 1024) {
		if(pte_index >= 0 && pte_index < 1024) {

		page_table = get_pdir_entry(proc_index, pde_index) & 0xfffff000;
	
	//	page_table = pte_index*0xfffff000;

		if(page_table){

		
			return *((unsigned int *)page_table + pte_index);


			}
		}
	 }
  }

  return 0;

}
	/*
    unsigned int page_table =(unsigned int)(PDirPool[proc_index][pde_index]); 
    page_table = page_table & 0xfffff000;
    
    //page_table = pte_index*4; //calculating page table 

    if (page_table){
	    return ((unsigned int *) page_table )[pte_index];
    
    }
    	else{
    		return 0;
 } 
 
}
*/

/**************************************************************************************************/
/** TASK 7:
  * * Sets specified page table entry with the start address of physical page # [page_index]
  * - You should also set the given permission
  * Hint 1: Same as TASK 6
  */

void set_ptbl_entry(unsigned int proc_index, unsigned int pde_index, unsigned int pte_index, unsigned int page_index, unsigned int perm)
{   
    // TODO
    unsigned int pte_address= (unsigned int)(PDirPool[proc_index][pde_index]);
    pte_address = pte_address & 0xfffff000;


    if(pte_address==0)
    {
	    return;
    }

    ((unsigned int *)pte_address)[pte_index]=(unsigned int)(page_index *PAGESIZE | perm);
	//((unsigned int *)pte_address)[pte_index]=(unsigned int)(page_index<<12)| or + perm;

	}

   
/*******************************************************************************************************/
/** TASK 8:
  * * Set the specified page table entry in IDPTbl as the identity map.
  * - You should also set the given permission
  * Hint 1: Remember that c-language is row-major i.e. for a multi-dimensional array, 
  *         the consecutive elements of a row reside next to each other. 
  * eg. a 2-dimensional array: A[2][3] is stored in memory as follows. 
  *  [https://en.wikipedia.org/wiki/Row-_and_column-major_order]
  * | Address | Array access |
  * |---------|--------------|
  * | 0       |    A[0][0]   |
  * | 1       |    A[0][1]   |       address for A[i][j] is calculated as:
  * | 2       |    A[0][2]   |       addr = (i * num_columns + j) * size_of_each_entry
  * | 3       |    A[1][0]   |       eg. A[1][2] -> (1 * 3 + 2) * 1 = 5
  * | 4       |    A[1][1]   |
  * | 5       |    A[1][2]   |
  * |---------|--------------|
  */

void set_ptbl_entry_identity(unsigned int pde_index, unsigned int pte_index, unsigned int perm)
{
	
    // TODO
    //IDPTbl[pde_index][pte_index]=(pde_index * 1024 + pte_index)*PAGESIZE | perm;
	IDPTbl[pde_index][pte_index] = (pde_index << 22) | (pte_index << 12) | perm;

    }


/************************************************************************************************************/
/** TASK 9:
  * * Set the specified page table entry to 0
  * Hint 1: Remember that page directory entries also have permissions stored. Mask them out.
  * Hint 2: Remember to cast to a pointer before de-referencing an address.
  */

void rmv_ptbl_entry(unsigned int proc_index, unsigned int pde_index, unsigned int pte_index)
{
	/*
    // TODO
    unsigned int pt_address = (unsigned int)((int)PDirPool[proc_index][pte_index] & 0xfffff000);

    if (pt_address ==0){
	    return;
    }
    ((char**)pt_address)[pte_index]=0;
*/
	*((unsigned int*)(get_pdir_entry(proc_index, pde_index) & ~0xFFF) + pte_index) = 0;

    }




